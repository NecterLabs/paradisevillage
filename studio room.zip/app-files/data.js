var APP_DATA = {
  "scenes": [
    {
      "id": "0-5",
      "name": "5",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 960,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.1011078166201695,
          "pitch": 0.23906281142329888,
          "rotation": 0,
          "target": "4-4"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-1",
      "name": "1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 960,
      "initialViewParameters": {
        "yaw": 2.3820682419613117,
        "pitch": 0.020543770471721956,
        "fov": 1.311866485837528
      },
      "linkHotspots": [
        {
          "yaw": 2.11106662034089,
          "pitch": 0.1497770578400619,
          "rotation": 0,
          "target": "2-2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-2",
      "name": "2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 960,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.1815028119347133,
          "pitch": 0.16825969309087263,
          "rotation": 0,
          "target": "1-1"
        },
        {
          "yaw": 0.4554476199129933,
          "pitch": 0.16418432568571717,
          "rotation": 0,
          "target": "3-3"
        },
        {
          "yaw": 1.6304977846235733,
          "pitch": 0.16480722767247968,
          "rotation": 0,
          "target": "4-4"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-3",
      "name": "3",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 960,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.5193856614417598,
          "pitch": 0.16679685086930007,
          "rotation": 0,
          "target": "2-2"
        },
        {
          "yaw": -1.1039215459516463,
          "pitch": 0.17704161098400917,
          "rotation": 0,
          "target": "4-4"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-4",
      "name": "4",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 960,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.6774539369689112,
          "pitch": 0.079760950377608,
          "rotation": 0,
          "target": "2-2"
        },
        {
          "yaw": -2.75541260903743,
          "pitch": 0.21708563265665148,
          "rotation": 0,
          "target": "0-5"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
